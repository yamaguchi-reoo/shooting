#pragma once
#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720