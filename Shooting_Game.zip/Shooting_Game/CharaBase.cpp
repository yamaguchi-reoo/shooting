#include "CharaBase.h"

void CharaBase::Update()
{
}

void CharaBase::Draw() const
{
}

void CharaBase::Hit()
{
}
