#include "BulletsSpawner.h"

void BulletsSpawner::Shoot()
{
}
